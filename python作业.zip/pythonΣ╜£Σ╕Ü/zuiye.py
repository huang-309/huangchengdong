#- * -coding: utf - 8 -
"""
- 每行代码，或每个方法要求添加注释（基础不好的同学）

题目内容：

1. ⼀个回合制游戏，有两个英雄，分别以两个类进⾏定义。分别是Timo和Jinx。每个英雄都有 hp 属性和 power属性，hp 代表⾎量，power 代表攻击⼒
2. 每个英雄都有⼀个 fight ⽅法， fight ⽅法需要传⼊“enemy_hp”（敌⼈的⾎量），“enemy_power”（敌⼈的攻击⼒）两个参数。需要计算对打一轮过后双方的最终血量，
英雄最终的⾎量 = 英雄hp属性-敌⼈的攻击⼒enemy_power
敌⼈最终的⾎量 = 敌⼈的⾎量enemy_hp-英雄的power属性

3. 对⽐英雄最终的⾎量和敌⼈最终的⾎量，⾎量剩余多的⼈获胜。如果英雄赢了打印 “英雄获胜”，如果敌⼈赢了，打印“敌⼈获胜”

4. 使用继承、简单工厂方法等各种方式优化你的代码
"""
class hero():
    #定义类
    hero_hp = 0
    hero_power = 0
    hero_name = ""
    def fight(self,enemy_hp,enemy_power,enemy_name):
        """
        :param enemy_hp: 敌人血量
        :param enemy_power: 敌人攻击力
        :param enemy_name: 敌人姓名
        :return:
        """
        hero_final_hp = self.hero_hp - enemy_power
        enemy_final_hp = enemy_hp - self.hero_power
        if hero_final_hp > enemy_final_hp:
            print(f"{self.hero_name}获胜")
        elif hero_final_hp == enemy_final_hp:
            print(f"平局")
        else:
            print(f"{enemy_name}敌人获胜")

class Timo(hero):
    #定义子类，继承父类的方法与属性
    hero_hp = 1200
    hero_power = 200
    hero_name = "timo"
class Jinx(hero):
    # 定义子类，继承父类的方法与属性
    hero_hp = 1200
    hero_power = 2000
    hero_name = "jinx"


timo = Timo()
#类实例化，类.()
#timo.fight( Jinx.hero_hp,Jinx.hero_power,Jinx.hero_name)

jinx = Jinx()
jinx.fight(Timo.hero_hp,Timo.hero_power,Timo.hero_name)
#传参，传递类方法需要的参数

