
from zuiye import Timo, Jinx

class Factory:
    #定义hero函数
    def hero_management(self,name):
        if name == "timo":
            #快捷导入实例对象(类())使用alt/option +回车:导入的同时顶部自动写入导入的模块
            return Timo()
        elif name == "jinx":
            return Jinx()
        else:
            raise Exception("此英雄不在此处")

factory = Factory()
factory.hero_management("timo")
#传参打印方式1
#jinx = factory.hero_management("timo")
#jinx.fight( Timo.hero_hp,Timo.hero_power,Timo.hero_name)
#请问老师：学习视频中还使用了后面这两行代码，不是直接使用方式1就可以得出结果吗？而且时候后面两行代码会执行出两个结果，为什么还要这么写，不能直接使用下面的写法吗？


"""
from zuiye import Timo, Jinx


class Factory:
    def Hero_collection(self,name):
        if name == "timo":
            return Timo()
        elif name == "jinx":
            return Jinx()
        else:
            raise Exception
faceory = Factory()
faceory.Hero_collection("jinx")

"""



























